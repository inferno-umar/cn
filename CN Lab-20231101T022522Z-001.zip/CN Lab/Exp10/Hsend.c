/*
Experiment No : 10

Name: Siddiqui Umar Farooque
Roll No. : 21CO57
Batch : 4
Sem : 5


Aim : WAP to perform Hamming Code.


What is Hamming Code?
     Hamming code is a set of error-correction codes that can be used to 
     detect and correct the errors that can occur when the data is moved or 
     stored from the sender to the receiver. It is a technique developed by 
     R.W. Hamming for error correction. Redundant bits – Redundant bits are 
     extra binary bits that are generated and added to the information-carrying 
     bits of data transfer to ensure that no bits were lost during the data transfer. 
*/

//Program :
#include<stdio.h>
void main() 
{
    int data[10],i;
    printf("Enter 4 bits of data one by one\n");
    scanf("%d",&data[0]);
    scanf("%d",&data[1]);
    scanf("%d",&data[2]);
    scanf("%d",&data[4]);
 
    //Calculation of redundancy bits
    data[6]=data[0]^data[2]^data[4];
    data[5]=data[0]^data[1]^data[4];
    data[3]=data[0]^data[1]^data[2];
 
    printf("\nEncoded data is\n");
    for(i=0;i<7;i++)
        printf("%d",data[i]);
}

