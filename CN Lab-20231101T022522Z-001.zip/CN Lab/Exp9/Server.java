/*
Experiment No : 9

Name: Siddiqui Umar Farooque
Roll No. : 21CO57
Batch : 4
Sem : 5


Aim : WAP to perform Selective Repeat flow control protocol.


What is Selective Repeat?
     It is also known as Sliding Window Protocol and used 
	 for error detection and control in the data link layer.

	 In the selective repeat, the sender sends several frames 
	 specified by a window size even without the need to wait for 
	 individual acknowledgement from the receiver as in Go-Back-N ARQ. 
	 In selective repeat protocol, the retransmitted frame is received out of sequence.

	 In Selective Repeat ARQ only the lost or error frames are retransmitted, 
	 whereas correct frames are received and buffered.

	 The receiver while keeping track of sequence numbers buffers the frames 
	 in memory and sends NACK for only frames which are missing or damaged. 
	 The sender will send/retransmit a packet for which NACK is received.
*/

//Program :
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import java.net.SocketException;

public class Server {
	static ServerSocket Serversocket;
	static DataInputStream dis;
	static DataOutputStream dos;

	public static void main(String[] args) throws SocketException {

		try {
			int a[] = { 30, 40, 50, 60, 70, 80, 90, 100 };
			Serversocket = new ServerSocket(8011);
			System.out.println("waiting for connection");
			Socket client = Serversocket.accept();
			dis = new DataInputStream(client.getInputStream());
			dos = new DataOutputStream(client.getOutputStream());
			System.out.println("The number of packets sent is:" + a.length);
			int y = a.length;
			dos.write(y);
			dos.flush();

			for (int i = 0; i < a.length; i++) {
				dos.write(a[i]);
				dos.flush();
			}

			int k = dis.read();

			dos.write(a[k]);
			dos.flush();

		} catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				dis.close();
				dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}

/*			 OUTPUT

	[sinhgad@localhost ~]$ su
Password: 
[root@localhost sinhgad]# javac ser.java
[root@localhost sinhgad]# java ser
waiting for connection
The number of packets sent is:8
[root@localhost sinhgad]# 

*/
