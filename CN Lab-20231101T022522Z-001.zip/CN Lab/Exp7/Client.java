/*
Experiment No : 7

Name: Umar Farooque
Roll No. : 21co57
Batch : 4
Sem : 5


Aim : WAP to perform TCP calculator.


What is TCP?
    Transmission Control Protocol (TCP) is a communications standard 
    that enables application programs and computing devices to exchange 
    messages over a network. It is designed to send packets across the 
    internet and ensure the successful delivery of data and messages over networks.
*/

//Program :
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
 
public class Client
{
    public static void main(String[] args) throws IOException
    {
        InetAddress ip = InetAddress.getLocalHost();
        int port = 4444;
        Scanner sc = new Scanner(System.in);
 
        // Step 1: Open the socket connection.
        Socket s = new Socket(ip, port);
 
        // Step 2: Communication-get the input and output stream
        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
 
        while (true)
        {
            // Enter the equation in the form-
            // "operand1 operation operand2"
            System.out.print("Enter the equation in the form: ");
            System.out.println("'operand operator operand'");
 
            String inp = sc.nextLine();
 
            if (inp.equals("bye"))
                break;
 
            // send the equation to server
            dos.writeUTF(inp);
 
            // wait till request is processed and sent back to client
            String ans = dis.readUTF();
            System.out.println("Answer=" + ans);
        }
    }
}
