/*
Experiment No : 5

Name: Umar Farooque
Roll No. : 21co57
Batch : 4
Sem : 5


Aim : WAP to perform CRC.


What is CRC?
    A cyclic redundancy check (CRC) is an error-detecting code commonly used in digital networks and storage devices to detect accidental changes to digital data. Blocks of data entering these systems get a short check value attached, based on the remainder of a polynomial division of their contents. On retrieval, the calculation is repeated and, in the event the check values do not match, corrective action can be taken against data corruption. CRCs can be used for error correction (see bitfilters).
*/

//Program : 

#include <stdio.h>
#include <string.h>

int main() {
	int i,j,keylen,msglen;
	char input[100], key[30],temp[30],quot[100],rem[30],key1[30],nmsg[20];
	printf("\nEnter Data: ");
	scanf("%s",input);
		printf("Enter Key: ");
	scanf("%s",key);
	keylen=strlen(key);
	msglen=strlen(input);
	strcpy(key1,key);
	for (i=0;i<keylen-1;i++) {
		input[msglen+i]='0';
	}
	for (i=0;i<keylen;i++)
	    temp[i]=input[i];        
	for (i=0;i<msglen;i++) {
		quot[i]=temp[0];
		if(quot[i]=='0')
		 for (j=0;j<keylen;j++)
		 key[j]='0'; else
		 for (j=0;j<keylen;j++)
		 key[j]=key1[j];
		for (j=keylen-1;j>0;j--) {
			if(temp[j]==key[j])
			 rem[j-1]='0'; else
			 rem[j-1]='1';
		}
		rem[keylen-1]=input[i+keylen];
		strcpy(temp,rem);
	}
	strcpy(rem,temp);
	printf("\nQuotient is ");
	for (i=0;i<msglen;i++)
	    printf("%c",quot[i]);
	printf("\nRemainder is ");
	
	for (i=0;i<keylen-1;i++)
	    printf("%c",rem[i]);
	printf("\nFinal data is: ");
	
	int newmsglen;
	newmsglen = msglen+keylen-1;
	
	for(i=msglen;i<(msglen+keylen-1);i++)
	 	input[i]=rem[i-msglen];
	 	
	for (i=0;i<newmsglen;i++)
	    printf("%c",input[i]);
	 
	printf("\n\nEnter the Received Data : ");
	scanf("%s",input);
	
	for (i=0;i<keylen;i++)
	    temp[i]=input[i];
	for (i=0;i<msglen;i++) 
	{
		quot[i]=temp[0];
		
		if(quot[i]=='0')
    	    for (j=0;j<keylen;j++)
    	        key[j]='0'; 
		else
		    for (j=0;j<keylen;j++)
		        key[j]=key1[j];
		        
		for (j=keylen-1;j>0;j--) 
		{
			if(temp[j]==key[j])
			 rem[j-1]='0'; else
			 rem[j-1]='1';
		}
		rem[keylen-1]=input[i+keylen];
		strcpy(temp,rem);
	}
	int flag=0;
	strcpy(rem,temp);
	for(i=0;i<keylen-1;i++)
	{
		if(rem[i]=='0')
	 		continue;
		else
			flag=1;
	}
	if(flag==1)
		printf("\nSince Remainder Is Not 0 Hence Message Transmitted From Sender To Receriver Contains Error");
	
	else
		printf("\nSince Remainder Is 0 Hence Message Transmitted From Sender To Receriver Is Correct\n");
	
	 return 0;
}

/*
Output :

sh-5.1$ gcc crc.c
sh-5.1$ ./a.out

Enter Data: 10110101
Enter Key: 10001

Quotient is 10111110
Remainder is 1110
Final data is: 101101011110

Enter the Received Data : 101101011110

        Since Remainder Is 0 Hence Message Transmitted From Sender To Receriver Is Correct


*/
